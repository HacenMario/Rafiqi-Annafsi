"use client";

/**
 * v2.9.0 — تمرين تهدئة النفس 4-4-6 (تمرين فعّال وليس لعبة)
 * ─────────────────────────────────────────────────────────────
 * تقنية تنفّس موجّهة يستعملها المختصون فعلياً لتهدئة الجهاز العصبي:
 *   • شهيق 4 ثوانٍ من الأنف
 *   • حبس 4 ثوانٍ
 *   • زفير 6 ثوانٍ من الفم (الزفير الأطول يفعّل الاستجابة المريحة)
 * 5 دورات فقط تكفي لخفض التوتر الحاد. دائرة متحركة تقود الإيقاع،
 * وعدّاد زمني لكل طور حتى لا يحتاج المستخدم إلى العدّ بنفسه.
 * يُفتح من زر في الهيدر (كل الصفحات) ومن بطاقة على الصفحة الرئيسية.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Wind, X } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

type Phase = "in" | "hold" | "out";
const PHASES: { key: Phase; seconds: number }[] = [
  { key: "in", seconds: 4 },
  { key: "hold", seconds: 4 },
  { key: "out", seconds: 6 },
];
const TOTAL_CYCLES = 5;

export function BreathingExerciseDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { t } = useI18n();
  const [running, setRunning] = useState(false);
  const [phaseIdx, setPhaseIdx] = useState(0);
  const [cycle, setCycle] = useState(1);
  const [remaining, setRemaining] = useState(0);
  const [finished, setFinished] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stop = useCallback(() => {
    setRunning(false);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
  }, []);

  const reset = useCallback(() => {
    stop();
    setPhaseIdx(0);
    setCycle(1);
    setRemaining(PHASES[0].seconds);
    setFinished(false);
  }, [stop]);

  const start = useCallback(() => {
    reset();
    setRunning(true);
  }, [reset]);

  useEffect(() => {
    if (open) reset();
    else stop();
  }, [open, reset, stop]);

  useEffect(() => {
    if (!running) return;
    timerRef.current = setInterval(() => {
      setRemaining((r) => {
        if (r > 1) return r - 1;
        /* انتقال الطور */
        setPhaseIdx((pi) => {
          const next = pi + 1;
          if (next < PHASES.length) {
            setRemaining(PHASES[next].seconds);
            return next;
          }
          /* انتهت الدورة */
          setCycle((c) => {
            if (c + 1 > TOTAL_CYCLES) {
              setFinished(true);
              setRunning(false);
              return c;
            }
            setRemaining(PHASES[0].seconds);
            return c + 1;
          });
          return 0;
        });
        return r;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = null;
    };
  }, [running]);

  const phase = PHASES[phaseIdx];
  const phaseLabel = phase.key === "in" ? t.breathing.phaseIn : phase.key === "hold" ? t.breathing.phaseHold : t.breathing.phaseOut;
  const scale = phase.key === "in" ? 1 : phase.key === "hold" ? 1 : 0.55;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-start flex items-center gap-2">
            <Wind className="h-5 w-5 text-primary" />
            {t.breathing.title}
          </DialogTitle>
        </DialogHeader>
        <p className="text-xs font-semibold text-muted-foreground -mt-1 leading-relaxed">{t.breathing.subtitle}</p>

        <div className="py-2 flex flex-col items-center gap-5">
          {running ? (
            <>
              {/* الدائرة الموجّهة — تتوسع بالشهيق وتنكمش بالزفير */}
              <div className="relative h-52 w-52 flex items-center justify-center">
                <motion.div
                  key={`${phaseIdx}-${cycle}`}
                  animate={{ scale }}
                  transition={{ duration: phase.seconds, ease: phase.key === "out" ? "easeOut" : "easeInOut" }}
                  className="absolute inset-0 rounded-full gradient-primary opacity-25"
                />
                <motion.div
                  key={`${phaseIdx}-${cycle}-inner`}
                  animate={{ scale: scale + 0.15 }}
                  transition={{ duration: phase.seconds, ease: phase.key === "out" ? "easeOut" : "easeInOut" }}
                  className="absolute inset-6 rounded-full gradient-primary opacity-50"
                />
                <div className="relative z-10 text-center">
                  <div className="text-5xl font-black font-mono tabular-nums" dir="ltr">
                    {remaining}
                  </div>
                  <div className="text-[10px] font-bold text-muted-foreground">{t.breathing.seconds}</div>
                </div>
              </div>
              <div className="text-center space-y-1">
                <p className="font-black text-lg">{phaseLabel}</p>
                <p className="text-xs font-bold text-muted-foreground">
                  {t.breathing.cycleOf.replace("{n}", String(cycle)).replace("{total}", String(TOTAL_CYCLES))}
                </p>
              </div>
            </>
          ) : finished ? (
            <div className="text-center space-y-4 py-6">
              <div className="w-20 h-20 mx-auto rounded-full bg-primary/10 flex items-center justify-center text-4xl">🌿</div>
              <p className="font-black text-lg">{t.breathing.done}</p>
              <Button className="gradient-primary text-white font-black rounded-xl" onClick={start}>
                {t.breathing.doneAgain}
              </Button>
            </div>
          ) : (
            <div className="text-center space-y-5 py-4">
              <div className="w-24 h-24 mx-auto rounded-full gradient-primary opacity-25 flex items-center justify-center">
                <Wind className="h-10 w-10 text-primary" />
              </div>
              <p className="text-xs font-semibold text-muted-foreground leading-relaxed max-w-72">{t.breathing.hint}</p>
              <Button size="lg" className="gradient-primary text-white font-black rounded-xl h-12 px-8" onClick={start}>
                {t.breathing.start}
              </Button>
            </div>
          )}
        </div>

        {running && (
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1 rounded-xl font-bold" onClick={stop}>
              {t.breathing.stop}
            </Button>
          </div>
        )}
        <button
          onClick={() => onOpenChange(false)}
          className="w-full py-1.5 text-center text-[11px] font-bold text-muted-foreground hover:text-primary transition-colors flex items-center justify-center gap-1"
        >
          <X className="h-3 w-3" />
          {t.common.close}
        </button>
      </DialogContent>
    </Dialog>
  );
}

/** زر مختصر يُستعمل في الهيدر والصفحات */
export function BreathingTriggerButton({ className }: { className?: string }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button
        variant="ghost"
        size="sm"
        className={`gap-1.5 font-bold text-primary hover:text-primary ${className || ""}`}
        onClick={() => setOpen(true)}
        title={t.breathing.openBtn}
      >
        <Wind className="h-4 w-4" />
        <span className="hidden sm:inline text-xs">{t.breathing.openBtn}</span>
      </Button>
      <BreathingExerciseDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
