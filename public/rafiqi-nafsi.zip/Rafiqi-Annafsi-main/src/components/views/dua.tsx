"use client";

/**
 * v2.9.0 — صفحة الدعاء.
 * أطلب من كل من أعجب بالصفحة أو أفادته أن يدعي لأمي الحبيبة بالشفاء
 * العاجل، وأن يفرج كرب أخي رفيق، وأن يحفظ أبي وكل والدينا…
 * الصفحة تحفظ الدعاء في جدارية أنيقة، وزر «آمين» يقيّم المشاركة
 * محلياً (بلا أي رصد للهوية — عدّاد في هذا الجهاز فقط).
 */
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { HeartHandshake, Copy, Check, HandHeart } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { BackButton } from "@/components/shared/back-button";

const AMEN_KEY = "rafiqi-dua-amen";

export function DuaView() {
  const { t, lang } = useI18n();
  const [amen, setAmen] = useState(false);
  const [amenCount, setAmenCount] = useState(1);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setAmen(localStorage.getItem(AMEN_KEY) === "1");
    const n = Number(localStorage.getItem(`${AMEN_KEY}-count`) || "1");
    setAmenCount(Number.isFinite(n) && n > 0 ? n : 1);
  }, []);

  const sayAmen = () => {
    if (amen) return;
    const n = amenCount + 1;
    localStorage.setItem(AMEN_KEY, "1");
    localStorage.setItem(`${AMEN_KEY}-count`, String(n));
    setAmen(true);
    setAmenCount(n);
  };

  const copyDua = async () => {
    const text = `${t.dua.title}\n\n${t.dua.intro}\n${t.dua.items.map((x, i) => `${i + 1}. ${x}`).join("\n")}\n\nآمين 🤲`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      /* المتصفح قد يمنع النسخ */
    }
  };

  const isAr = lang === "ar";

  return (
    <div className="max-w-2xl mx-auto px-4 py-10 md:py-14">
      <BackButton />
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div className="text-center space-y-3">
          <div className="w-16 h-16 mx-auto rounded-full bg-amber-400/15 flex items-center justify-center">
            <HeartHandshake className="h-8 w-8 text-amber-500" />
          </div>
          <h1 className="text-2xl md:text-3xl font-black">{t.dua.title}</h1>
          <p className="text-muted-foreground leading-relaxed max-w-lg mx-auto">{t.dua.subtitle}</p>
        </div>

        <Card className="border-amber-400/40 bg-gradient-to-b from-amber-400/[0.07] to-transparent overflow-hidden relative">
          {/* زخرفة إسلامية خفيفة في الزوايا */}
          <div className="absolute top-0 start-0 w-14 h-14 border-s-4 border-t-4 border-amber-400/30 rounded-ss-3xl" aria-hidden="true" />
          <div className="absolute bottom-0 end-0 w-14 h-14 border-e-4 border-b-4 border-amber-400/30 rounded-ee-3xl" aria-hidden="true" />
          <CardContent className="p-6 sm:p-8 space-y-5">
            <p className="font-black text-base text-amber-700 dark:text-amber-400 text-center" dir="auto">
              {t.dua.intro}
            </p>
            <ul className="space-y-3">
              {t.dua.items.map((item, i) => (
                <motion.li
                  key={i}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.08 * i }}
                  className="flex items-start gap-3 rounded-xl bg-card border border-border/70 px-4 py-3"
                >
                  <span className="shrink-0 h-7 w-7 rounded-full bg-amber-400/15 text-amber-600 dark:text-amber-400 text-xs font-black flex items-center justify-center">
                    {i + 1}
                  </span>
                  <p className="text-sm font-semibold leading-relaxed flex-1" dir="auto">
                    {item}
                  </p>
                </motion.li>
              ))}
            </ul>

            <div className="pt-2 text-center space-y-3">
              <Button
                size="lg"
                className={`h-13 px-10 text-base font-black rounded-2xl ${amen ? "bg-amber-500/20 text-amber-700 dark:text-amber-300" : "gradient-primary text-white"}`}
                onClick={sayAmen}
                disabled={amen}
              >
                <HandHeart className="h-5 w-5" />
                {amen ? t.dua.amenDone : t.dua.amen}
              </Button>
              {!amen && <p className="text-[11px] font-semibold text-muted-foreground">{t.dua.amenNote}</p>}
              {amen && (
                <p className="text-[11px] font-bold text-amber-600 dark:text-amber-400" dir="ltr">
                  {t.dua.amenCount.replace("{n}", String(amenCount))}
                </p>
              )}
              <button
                onClick={copyDua}
                className="inline-flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground hover:text-primary transition-colors"
              >
                {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? t.common.success : t.counselor.copyPublicLink}
              </button>
            </div>
          </CardContent>
        </Card>

        {!isAr && (
          <p className="text-[11px] font-semibold text-muted-foreground text-center leading-relaxed" dir="rtl">
            الدعاء الأصلي بالعربية — والدعاء بمحبتها وترجمتها مقبول بإذن الله
          </p>
        )}
      </motion.div>
    </div>
  );
}
